package sae;

public class Standard extends Categorie{

	private static int ID = 1;
	
	public Standard(int superficie,int capacite,int prix) {
		super(superficie, capacite, prix);
	}

	public static int getID() {
		return ID;
	}
	
	public void afficher() {
		System.out.println("Simple standard : " + this.getSuperficie() + "cap : " + this.getCapacite() + "prix" + this.getPrix());
	}
	
	@Override
	public String toString() {
		return "Standard";
	}
}
