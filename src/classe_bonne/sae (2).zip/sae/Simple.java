package sae;

public class Simple extends Categorie{

	private static int ID = 3;
	private String mode;
	
	public Simple(int superficie,int capacite,int prix, String mode) {
		super(superficie, capacite, prix);
		this.mode = mode;
	}

	public static int getID() {
		return ID;
	}
	
	public String getMode () {
		return this.mode;
	}
	
	public void setMode(String m) {
		this.mode = m;
	}
	
	public void afficher() {
		System.out.println("Simple Sup : " + this.getSuperficie() + " cap : " + this.getCapacite() + " prix" + this.getPrix()+ " mode : " + this.mode );
	}

	@Override
	public String toString() {
		return "Simple";
	}
	
}
