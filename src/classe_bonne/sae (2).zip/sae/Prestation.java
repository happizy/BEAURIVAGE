package sae;

public abstract class Prestation {

	public abstract void consulterPrestation();
	
}
