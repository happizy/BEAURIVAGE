package sae;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
	public void start(Stage primaryStage) throws Exception {
		primaryStage = new FenListeEmp();
		primaryStage.show();
	}
	public static void main(String[] args) {
		Application.launch();
}
}
