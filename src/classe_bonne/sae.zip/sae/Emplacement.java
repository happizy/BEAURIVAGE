package sae;

import java.util.Date;

public class Emplacement{

	private int numero;
	private Categorie categorie;
	private Contrat contrat;
	
	public Emplacement(int numero, Categorie categorie,Contrat contrat) {
		this.numero = numero;
		this.categorie = categorie;
		this.contrat = contrat;

	}

	public Contrat getContrat() {
		return contrat;
	}

	public void setContrat(Contrat contrat) {
		this.contrat = contrat;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public Categorie getCategorie() {
		return categorie;
	}

	public void setCategorie(Categorie categorie) {
		this.categorie = categorie;
	}
	
	public String getDateArrivee() {
		return contrat.getDateArrive();
	}
	
	public String getDateDepart() {
		return contrat.getDateDepart();
	}
	
	public int getNumCli() {
		return contrat.getNoClient();
	}
	
	public String getNomCli() {
		return contrat.getNomClient();
	}
	
	public void afficher () {
		System.out.println("num emplacement : " + this.numero);
		this.categorie.afficher();
		this.contrat.afficherContrat();
	}
	public static void main(String[] args) {
		Categorie c = new Simple(40,6,150,"tente");
		Client client = new Client ("Bob", "Robert", "20 rue des chemins");
		Contrat cont = new Contrat("05/07/2022", "15/07/2022", 80, 400,"courier", "pres jeu pour enfants" ,client);
		Emplacement emp = new Emplacement(18, c ,cont);
		emp.afficher();
	}
	
	
}
