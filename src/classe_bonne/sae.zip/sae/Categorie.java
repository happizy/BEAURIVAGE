package sae;


public abstract class Categorie {
	
		


	private int superficie;
	private int capacite;
	private int prix;
	public Categorie(int superficie, int capacite, int prix) {
		super();
		this.superficie = superficie;
		this.capacite = capacite;
		this.prix = prix;
	}
	
	
	public int getSuperficie() {
		return superficie;
	}


	public void setSuperficie(int superficie) {
		this.superficie = superficie;
	}


	public int getCapacite() {
		return capacite;
	}


	public void setCapacite(int capacite) {
		this.capacite = capacite;
	}


	public int getPrix() {
		return prix;
	}


	public void setPrix(int prix) {
		this.prix = prix;
	}


	public abstract void afficher();

	
}
